#include <stdio.h>
#include <stdlib.h>

//Kĩ thuật khai báo mảng và gán luôn giá trị
//int a = 10; Vậy mảng có làm được thế này không?
int main(int argc, char *argv[]) {
	//Mảng giống với tập hợp ở toán học phổ thông
	float c[10] = {1, 1, 2, 3, 5, 8}; //Cho 6 điểm thôi mà lại có 10 biến 
									//gán value ngay cho 6 phần tử đầu của mảng. c[0] = 1; c[5] = 8
									//Các biến còn lại value DEFAULT = 0; Không rác lung tung
	printf("Your ten grades\n");
	for (int i = 0; i < 10; i++) {
		printf("Grade [%d] = %.2f\n", i, c[i]);
	float col[] = {2, 4, 6, 8, 10}; //Câu lệnh này không nói rõ có bao nhiêu biến được cấp nhưng lại gắn sẵn
									//value cho 1 số biến. Lúc này mảng tự động cấp số biến tùy vào số lượng
									//value được gán. Bài này tương đương col[5] với 5 value
	}
									
	return 0;
}