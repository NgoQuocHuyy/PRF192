#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	int a = 23;
	int b = 100;
	int tmp; //t, tmp, temporary: biến trung gian, biến tạm dùng để back up lại value
	printf("Before swapping, a = %d; b = %d\n", a, b);
	tmp = a; //Cất lại value a trước khi hoán đổi giá trị
	a = b;// a lấy 100 của b, mất giá trị 23 nhưng không lo vì t giữ value và đẩy cho b sau 
	b = tmp; //b lấy giá trị đầu của a đang nằm ở tmp
	printf("After swapping, a = %d; b = %d\n", a, b);
	
	return 0;
}