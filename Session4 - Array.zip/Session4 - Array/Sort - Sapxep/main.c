#include <stdio.h>
#include <stdlib.h>

//Cho 1 mảng 10 phần tử. Tìm con số nhỏ nhất trong mảng và đưa nó lên đầu mảng

int main(int argc, char *argv[]) {
	int a[] = {-5, 10, 100, -50, 100, -1001, 1};
	int min = a[0];
	int pos = 0; //mặc định nhỏ nhất là thằng đầu tiên 
	int tmp;
	for (int i = 1; i < 7; i++)
		if (a[i] < min) {
			min = a[i];
			pos = i; //vị trí i thấy a[i] < min
		}
	if (pos > 0) { //min nằm ở giữa mảng, hoán đổi
		 tmp = a[0];
		 a[0] = a[pos]; //pos là vị trí tìm thấy min trong mảng
		 a[pos] = tmp; //Giá trị cũ của a[0]
	}
	printf("After swapping, the array now is:\n");
	for (int i = 0; i < 7; i++)
		printf("%d  ", a[i]);
	return 0;
}