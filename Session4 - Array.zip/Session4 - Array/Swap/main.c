#include <stdio.h>
#include <stdlib.h>

//Hoán đổi giá trị của 2 biến cho nhau
int main(int argc, char *argv[]) {
	int a = 23;
	int b = 100;
	printf("Before swapping, a = %d; b = %d\n", a, b);
	a = b; // a lấy giá trị của b nên a = b = 100
	b = a; // b lấy giá trị của a mà a lúc này bằng 100 do lệnh trước 
	//Vậy ta phải cất giá trị a cũ đi trước khi đổi giá trị với b
	return 0;
}