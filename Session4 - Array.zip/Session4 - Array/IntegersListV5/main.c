#include <stdio.h>
#include <stdlib.h>
//Nhập vào từ bàn phím mảng 10 số nguyên bất kì. Hỏi có số 10 xuất hiện trong mảng hay không?
int main(int argc, char *argv[]) {
	int n[10];
	int pos = -1; //biến flag và lưu luôn vị trí tìm thấy
				// -1 để hiểu rằng 10 không được tìm thấy (vì mảng là từ 0 -> 9)
				//nếu pos >= 0...9 tức là đã thấy 10
	printf("Please input 10 numbers:\n");
	for (int i = 0; i < 10; i++) {
		printf("Input number #%d: ", (i + 1));
		scanf("%d", &n[i]);
	}
	//in mảng:
	printf("You have just input the following numbers\n");
	for (int i = 0; i < 10; i++)
		printf("%d\t", n[i]);
	printf("\n"); //in mảng xong phải xuống hàng
		
	//Tìm số 10 có xuất hiện hay không:
	for (int i = 0; i < 10; i++)
		if (n[i] == 10) {
			pos = i; //pos lưu vị trí nếu thấy - cờ phất
			break;
		}
	if (pos == 1)
		printf("10 not found\n");
	else printf("10 found at the position of %d\n", (pos + 1));
	return 0;
}