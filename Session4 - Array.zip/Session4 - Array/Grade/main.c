#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Muốn lưu 10 cột điểm của môn học 
int main(int argc, char *argv[]) {
	float c1, c2, c3, c4, c5, c6, c7, c8, c9, c10; //Column: cột. Kĩ thuật khai báo lẻ từng biến một
	c1 = 10.0;
	c2 = 9.0;
	c3 = 9.5;
	float c[10]; //Giống cách trên là có được 10 biến nhưng nhanh hơn, muốn bao nhiêu biến chỉ cần thay trong []
	c[0] = 10.0;
	c[1] = 9.0;
	c[2] = 9.5;
	printf("Bien le: %.2f %.2f %.2f\n", c1, c2, c3);
	printf("Bien mang: %.2f %.2f %.2f\n",c[0], c[1], c[2]);
	//Muốn nhập giá trị cho biến thường/biến mảng/phần tử của mảng
	printf("Input 2 grades (0...10): ");
	scanf("%f", c2); //biến thường
	scanf("%f", [c1]); //biến mảng
	printf("After inputing 2 grades, the current grades are:\n");
	printf("Bien le: %.2f %.2f %.2f\n", c1, c2, c3);
	printf("Bien mang: %.2f %.2f %.2f\n",c[0], c[1], c[2]);
	//Nếu muốn nhập hết 10 biến lẻ, 10 biến mảng thì
	scanf("%f %f %f %f %f %f %f", &c1, &c2, &c3, &c4, &c5, &c6);
	scanf("&f", &c[i]); //i chạy từ 0...9
	return 0;
}