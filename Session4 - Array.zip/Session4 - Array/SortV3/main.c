#include <stdio.h>
#include <stdlib.h>

//Cho 1 mảng. Sắp xếp mảng theo thứ tự tăng dần
//Mảng có bao nhiêu biến thì for bé hơn số biến. Mảng có 5 phần tử thì for < 5 vì đếm từ vị trí 0 
int main(int argc, char *argv[]) {
	int a[] = {-5, 10, 100, -50, 100, -1001, 1};
	int tmp;
	for (int i = 1; i < 7; i++)
		if (a[0] > a[i]) //tao là a[0] mà lại lớn hơn a sau -> sai chỗ -> đổi chỗ
		{
			tmp = a[0]; //cất a[0] đi
			a[0] = a[i]; //lấy value nhỏ hơn
			a[i] = tmp; //a[0] cũ
		}
		//Loại bỏ a[0], ta sắp xếp tiếp phần còn lại của mảng tức từ a[1] trở đi
	for (int i = 2; i < 7; i++) //1 là mốc thì quét từ 2
		if (a[1] > a[i]) 
		{
			tmp = a[1]; 
			a[1] = a[i]; 
			a[i] = tmp; 
		}
		//Phần tử nhỏ t2 đã xuất hiện về vị trí a[1]
		//Loại bỏ a[0] và a[1] ta quét từ a[2] về cuối mảng
	for (int i = 3; i < 7; i++)
		if (a[2] > a[i]) 
		{
			tmp = a[2]; 
			a[2] = a[i]; 
			a[i] = tmp; 
		}
	for (int i = 4; i < 7; i++)
		if (a[3] > a[i]) 
		{
			tmp = a[3]; 
			a[3] = a[i]; 
			a[i] = tmp; 
		}
	for (int i = 5; i < 7; i++)
		if (a[4] > a[i]) 
		{
			tmp = a[4]; 
			a[4] = a[i]; 
			a[i] = tmp; 
		}
	for (int i = 6; i < 7; i++)
		if (a[5] > a[i]) 
		{
			tmp = a[5]; 
			a[5] = a[i]; 
			a[i] = tmp; 
		}
	//Mảng đã sắp xếp xong theo thứ tự tăng dần.
	printf("After swapping, the array now is:\n");
	for (int i = 0; i < 7; i++)
		printf("%d  ", a[i]);
	return 0;
}