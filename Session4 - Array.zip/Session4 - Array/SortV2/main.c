#include <stdio.h>
#include <stdlib.h>

//Cho 1 mảng. Tìm con số nhỏ nhất trong mảng và đưa nó lên đầu mảng
//I: -5 10 100 -50 1000 1 -50 -1001
//   a[0] - min
// Lấy min so sánh lần lượt với a[1] và a[2] thì min vẫn là a[0] -> giữ nguyên
//Tiếp tục so sánh với a[3] thấy a[3] < a[0] ta đổi luôn vị trí và không cần dùng biến pos
//vì theo tính chất bắc cầu a[3] < a[0] mà a[0] < a[1] và a[2] -> a[3] < a[1] và a[2]
//Tiếp tục so sánh như vậy, mảng cuối cùng ta được là -1001 10 100 -5 1000 1 -50 -50
//Nên nhớ mục tiêu của bài toán chỉ là tìm phần tử bé nhất và đưa lên đầu mảng, còn phần sau lộn xộn kệ mẹ
//chúng m -> chưa tối ưu hóa 
int main(int argc, char *argv[]) {
	int a[] = {-5, -10, 100, -50, 100, -1001, 1};
	//        [0]
	//             [1] m có nhỏ hơn hay không?có thì đổi đi
	//         -10, -5
	//         -10         [2] có nhỏ hơn [0] hay không? 
	//         -10  -5  100 [3] có nhỏ hơn [0] hay không?
	//         -50 -10 -5 100 [5] có nhỏ hơn [0] hay không?
	//         -1001 -50 -10 -5 100 1
	int tmp;
	for (int i = 1; i < 7; i++)
		if (a[0] > a[i]) //tao là a[0] mà lại lớn hơn a sau -> sai chỗ -> đổi chỗ
		{
			tmp = a[0]; //cất a[0] đi
			a[0] = a[i]; //lấy value nhỏ hơn
			a[i] = tmp; //a[0] cũ
		}
	printf("After swapping, the array now is:\n");
	for (int i = 0; i < 7; i++)
		printf("%d  ", a[i]);
	return 0;
}