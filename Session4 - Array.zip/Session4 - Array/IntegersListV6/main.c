#include <stdio.h>
#include <stdlib.h>
//Nhập vào từ bàn phím mảng 10 số nguyên bất kì. Hỏi có số bất kì muốn nhập xuất hiện trong mảng hay không?
int main(int argc, char *argv[]) {
	//Khai báo mảng 10 số nguyên:
	int n[10];
	//Nhập mảng:
	printf("Input 10 numbers:\n");
	for (int i = 0; i < 10; i++) {
		printf("Input number %d: ", (i + 1));
		scanf("%d", &n[i]);
	}
	//In mảng đã nhập:
	printf("You have just input the following numbers\n");
	for (int i = 0; i < 10; i++)
		printf("%d\t", n[i]);
	printf("\n");
	//Nhập số cần tìm trong mảng:
	int x;
	printf("Input numbers you want to find in this array: ");
	scanf("%d", &x);
	//Tìm số cần tìm trong mảng:
	int pos = -1;
	for (int i = 0; i < 10; i++)
		if (n[i] == x) {
			pos = i;
			break;
		}
	//In kết quả
	if (pos == -1)
		printf("%d not found\n", x);
	else 
		printf("%d found in this array at position %d\n", x, (pos + 1));
	return 0;
}
	
	