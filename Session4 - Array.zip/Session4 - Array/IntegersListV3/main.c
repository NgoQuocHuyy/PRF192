#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int a[] = {5, 6, -1000, 100, 50, 70, 6, 6, -1, 10};
	int found = 0; //giả sờ ban đầu không thấy 10 cho đến khi thấy thì đổi trạng thái
					//biến sẽ giữ value cũ cho đến khi bị thay đổi
	for (int i = 0; i < 10; i++){
		if(a[i] == 10) {
			found = 1; //Bắt gặp 10 rồi - phất cờ và k tìm nữa
			break;
		}
	}
	//Kiểm tra flag để in kết quả
	if (found == 10)
		printf("Not found 10.\n");
	else
		printf("Found 10.\n");
	return 0;
}