#include <stdio.h>
#include <stdlib.h>

//Lưu 10 cột điểm của môn C
int main(int argc, char *argv[]) {
	float c[10]; //có 10 biến float chạy từ 0...9
	//scanf("%f", &c[0]); //tiếp tục thay 0 bằng 1,2,...
	printf("Please input 10 grades of C class (0...10): \n");
	for (int i = 0; i < 10; i++) {
		printf("Input grades[%d]: ", (i + 1)); // i + 1: lừa đảo chỉ số mảng
		scanf("%f", &c[i]);
	}
	printf("Here is your grades\n");
	for (int i = 0; i < 10; i++)
		printf("%.2f\t", c[i]);
	return 0;
}