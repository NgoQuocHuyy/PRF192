#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int a[] = {5, 6, -1000, 100, 50, 70, 6, 6, -1, 10};
	//Nên nhớ ta có 10 biến int đó là a[0], a[1],...
	//Duyệt mảng:
	for (int i = 0; i < 10; i++){
		if(a[i] == 10) {
			printf("Hey!Found 10 at position %d\n", i);
			break;
		}
		else
			printf("Not found 10\n");
		//LOGIC: Làm sao để chỉ in ra 1 dòng thông báo không thấy?. Vậy khi nào được quyền kết luận không thấy?
		//Vậy ta phải so sánh hết mà vẫn không thấy == 10 thì mới được đưa ra kết luận.
		//-> Biến cờ Flag - nguyên tắc suy đoán vô tội (đi hết cả mảng k thấy 10 thì cờ k phất, == 10 cờ phất lên)
		//Giả sử rằng 10 không xuất hiện từ đầu tiên:
		//check phần tử 1 == 10 không? - != 10 nhưng giả bộ vẫn đang đúng
		//check phần tử 2 == 10 không? - != 10 nhưng giả bộ vẫn đúng ...
		//check phần tử i == 10 không? - == 10 -> Cờ phất lên và không hỏi nữa - BREAK!
		//Quy ước: cờ = 0 là không tìm thấy, cờ = 1 là tìm thấy phần tử 10.
	}
	return 0;
}