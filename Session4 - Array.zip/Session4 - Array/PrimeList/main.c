#include <stdio.h>
#include <stdlib.h>

//Cho một mảng các số tự nhiên (nguyên dương). Hãy in ra các số nguyên tố xuất hiện trong mảng này 
//Ví dụ: 5, 10, 15, 23, 7, 9, 11, 13
//Nguyên tố: 5, 7, 11, 13, 23
//P: Duyệt mảng, đi qua từng phần tử [i] của mảng
//Đều hỏi lại 1 câu, [i] mày có là số nguyên tố không?
//Vấn đề lớn: Tìm và in các số nguyên tố
//Vấn đề nhỏ: Tìm một số có là số nguyên tố không?
//Mỗi vấn đề nhỏ là 1 hàm

//Hàm kiểm tra một số có phải là số nguyên tố
//I: Đầu vào của hàm - tham số argument/parameter
//P: 
//O: Có là nguyên tố hay không? có khả năng return value hay không?
int isPrime(int n); //Hàm loại 4 là hàm re-use cực tốt
// mày đưa n tao sẽ trả về 1 con int
//quy ước: 0: éo là nguyên tố
//         1: là nguyên tố
//y = isPrime(5) = 1
//y = isPrime(10) = 0
void printPrimeList(int a[], int size);
int main(int argc, char *argv[]) {
	//printf("23? %d\n", isPrime(23));
	//printf("101? %d\n", isPrime(101));
	//printf("99? %d\n", isPrime(99));
	int a[] = {5, 10, 15, 23, 7, 9, 11, 13};
	printPrimeList(a, 8);
	
}
int isPrime(int n) {
	int divisorsCount = 0; //số ước ban đầu bằng 0, nhồi con heo đất
	
	for (int i = 1; i <= n; i++)
		if (n % i == 0) //n có lỡ chia hết cho cháu i...n không?
			divisorsCount++; //Lỡ tay đếm ngay ước số
	//ngoài for
	if (divisorsCount == 2)
		return 1; //đúng là nguyên tố vì chỉ có 2 ước số
	else
		return 0;
	
	return 0;
}
// n là snt nếu nó chỉ có 2 ước số là 1 và chính nó
//thuật toán: đếm số ước số
//n : 1 lấy dư = 0 ->
//if n = 10 chia hết 1 tức là chia 1 dư 0 hoặc % 1 == 0 -> 1 ước số xuất hiện
//if n = 10 chia hết cho 2 tức là chia 2 dư 0 hoặc % 2 == 0 -> 1 ước số xuất hiện....
//Đếm tổng ước số: > 2 không là nguyên tố
void printPrimeList(int a[], int size) {
	int result;
	printf("The array has values of\n");
	for (int i = 0; i < size; i++)
		printf("%d ", *(a + i)); //a[1]
		
	//Quét mảng, lôi từng đứa ra hỏi có phải nguyên tố không
	printf("\nThe list of prime numbers in this array is\n");
	for (int i = 0; i < size; i++) {
		result = isPrime(a[i]); //result = 0 hoặc 1 trả về từ hàm
		if (result == 1) //mày là nguyên tố
			printf("%d ", a[i]);
	}
}

  


