#include <stdio.h>
#include <stdlib.h>

//Nhập 1 mảng n con số. In ra con số nhỏ nhất, lớn nhất của mảng
int main(int argc, char *argv[]) {
	int a[10];
	int min, max;
	//Nhập mảng và in mảng:
	printf("Please input 10 numbers:\n");
	for (int i = 0; i < 10; i++) {
		printf("Input number #%d: ", (i + 1));
		scanf("%d", &a[i]);
	}
	printf("You have just input the following number\n");
	for (int i = 0; i < 10; i++)
		printf("%d\t", a[i]);
	printf("\n");
	//Tìm max, min trong mảng:
	min = a[0]; //Phải chờ nhập xong thì mới có a[i] tức biến đầu mới có giá trị 
	max = a[0];
	for (int i = 1; i < 10; i++) { //Vì lấy giá trị đầu tức a[0] làm min nên a[i] = 1
		if (a[i] < min)
			min = a[i];
		if (a[i] > max)
			max = a[i];
}
	printf("The min value of this array is:%d\n", min);
	printf("The max value of this array is:%d\n", max);
	return 0;
}