#include <stdio.h>
#include <stdlib.h>

//Cho một mảng 5 con số. Sắp xếp theo thứ tự tăng dần
int main(int argc, char *argv[]) {
	int a[] = {5, -10, -15, -20, 25};
	int tmp;
	//Ta lấy [0] làm mốc quét từ [1], lấy [1] quét từ [2], lấy [2] quét từ [3], lấy [3] quét từ [4]
	//Lấy đến áp chót mảng, quét với cuối mảng là xong 
	printf("The array before ascending:\n");
	for (int i = 0; i < 5; i++)
		printf("%d ", a[i]);
	printf("\n");
	for (int i = 0; i < 5 - 1; i++) { // 5 - 1 vì lấy [3] xét với thằng cuối cùng là hết. Mảng chỉ có 4 phần tử
		for (int j = i + 1; j < 5; j++) //< 5 vì bên trên là 4 so với phần tử cuối là 5. Đây chính là vòng for cũ
			if (a[i] > a[j]) { // a[i] chính là a[0] và a[j] chính là a[i]
				tmp = a[i];
				a[i] = a[j];
				a[j] = tmp;
			}
		}
	printf("The array after sorting ascending:\n");
	for (int i = 0; i < 5; i++)
		printf("%d ", a[i]);	
			return 0;
}