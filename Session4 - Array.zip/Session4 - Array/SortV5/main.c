#include <stdio.h>
#include <stdlib.h>

//sắp xếp một mảng các số nguyên giảm dần
//Hàm hoán đổi 2 biến
void swap(int* a, int* b); //hàm nhận vào 2 con số để hoán đổi
//hàm này nhận vào 1 mảng có kích thước n và sắp xếp giảm dần, in ra kq
void sortArray(int a[], int size); //Có thể viết void sortArray(int* a, int size);
int main(int argc, char *argv[]) {
	//int x = 10, y = 100;
	//printf("Before swapping, x = %d; y = %d\n", x, y);
	//swap(&x, &y);
	//printf("After swapping, x = %d; y = %d\n", x, y);
	int n[] = {5, -10, -15, 20, -25, -1000};
	sortArray(n, 6);
	return 0;
}
/*
//Hàm cần một mảng, cần size để for, hàm 2 đầu vào
void sortArray(int a[], int size) {
	//In mảng trước khi sort
	printf("The array before sorting:\n");
	for (int i = 0; i < size; i++)
		//printf("%d ", a[i]);
		printf("%d ", *(a + i));
	//Sắp xếp mảng
	for (int i = 0; i < size - 1; i++)
		for (int j = i + 1; j < size; j++)
			if (a[i] < a[j]) {
			  int t = a[i];
				a[i] = a[j];
				a[j] = t; 
			}
	//In mảng sau khi sort:
	printf("\nThe array after sorting:\n");
	for (int i = 0; i < size; i++)
		printf("%d ", *(a + i));
	
}
*/
void sortArray(int a[], int size) {
	//In mảng trước khi sort
	printf("The array before sorting:\n");
	for (int i = 0; i < size; i++)
		//printf("%d ", a[i]);
		printf("%d ", *(a + i));
	//Sắp xếp mảng
	for (int i = 0; i < size - 1; i++)
		for (int j = i + 1; j < size; j++)
			if (a[i] < a[j]) //a[i] a[j] phải đổi value cho nhau
				swap(&a[i], &a[j]);
	//In mảng sau khi sort:
	printf("\nThe array after sorting:\n");
	for (int i = 0; i < size; i++)
		printf("%d ", *(a + i));
	
}
void swap(int* a, int* b) {
	int t = *a; //Đến nhà thằng x xa xa
	*a = *b; //đến nhà đứa y xa xa kia đổi value sang đứa x xa xa
	*b = t;//y xa xa kia sẽ bằng cũ của x đang nằm trong t
}
