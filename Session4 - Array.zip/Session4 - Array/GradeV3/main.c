#include <stdio.h>
#include <stdlib.h>

//Khảo sát RAM được cấp cho mảng
int main(int argc, char *argv[]) {
	float c[10]; //Đã có 10 biến từ c[0] -> c[9]
	//Hỏi nhà của 10 phần tử mảng ở đâu 
	/*
	printf("The addr of c[0] is %u\n", &c[0]);
	printf("The addr of c[1] is %u\n", &c[1]);
	printf("The addr of c[2] is %u\n", &c[2]);
	printf("The addr of c[3] is %u\n", &c[3]);
	printf("The addr of c[4] is %u\n", &c[4]);
	printf("The addr of c[5] is %u\n", &c[5]);
	printf("The addr of c[6] is %u\n", &c[6]);
	printf("The addr of c[7] is %u\n", &c[7]);
	printf("The addr of c[8] is %u\n", &c[8]);
	printf("The addr of c[9] is %u\n", &c[9]);
	*/
	printf("the addr of the element of the array:\n");
	for (int i = 0; i < 10; i++)
		printf("The addr of c[%d] is: %u\n", i, &c[i]);
	//[i] index chạy từ 0 đến cuối mảng 
	//Một điều đặc biệt khi chơi với mảng và nó dính đến truyền tham chiếu:
	//hàm mà nhận vào mảng thì không phải truyền giá trị kiểu copy mà là truyền tham chiếu (đưa giá trị thật)
	//Tên mảng rất đặc biệt:
	//tên mảng là tên chung cho tất cả các biến muốn khai báo
	//ex: float c[10]; ta có 10 biến từ c[0]... Ngoài ra C ngầm định còn 1 biến ẩn tên là c. Tên mảng được
	//xem là 1 biến đặc biệt. Nó không lưu value bình thường mà lưu value là địa chỉ của 1 biến khác!!!
	//Như vậy, tên mảng là 1 biến và nó lưu đại chỉ của element đầu mảng mà nó quản lý
	//ex: Cô giáo bị ốm (biến c) chỉ cần báo với lớp trưởng (element đầu dãy [0]), 
	//sau đó tự lớp trưởng sẽ thông báo cho các thành viên trong lớp.
	printf("The value of c is %d\n", &c);
	//In giá trị của một biến thì cứ % mà quất thôi. In địa chỉ thì mới dùng &!
	//%u: unsigned - số nguyên k dấu(số dương), %d: số nguyên có dấu (cả dương và âm). Địa chỉ chắc chắn là
	//số dương nên mình có thể dùng cả 2. Tuy nhiên %d sẽ bị hạn chế về mặt lưu trữ độ lớn dữ liệu so với %u
	//CHỐT: Mảng chẳng qua là làm việc với nhiều biến, cùng tên, phân biệt[biến thứ mấy]. Mảng hay chơi với 
	//for vì [tăng từ 0]. Một loạt các bài toán xuất hiện khi chơi với mảng vì có nhiều biến/value/data:
	//1. Nhập một loạt các con số từ bàn phím
	//2. Tìm sự xuất hiện của một con số nào đó. Ex: tìm số 10 có xuất hiện trong mảng số đã cho k. Hoặc nói 
	//rộng hơn là bài toán tìm kiếm người giữa tập hơp tên -> bài toán tìm kiếm trong cơ sở dữ liệu, app
	//3. Bài toán liệt kê, tìm những giá trị thảo mãn thì liệt kê ra. Ex: tìm các số chẵn trong mảng và in ra
	//Suy rộng là tìm các mẫu điện thoại apple/samsung và cho xem -> filter bộ lọc.
	//4. Đếm số lần xuất hiện của data nào đó. Ex: Số 10 xuất hiện mấy lần trong mảng
	//5. Sắp xếp tăng giảm. Một loạt các thuật toán sắp xếp xuất hiện 
	//6. Tìm min, max trong mảng - kĩ thuật phất cờ
	//7. Chỉnh sửa mảng:
	//- Xóa 1 phần tử, tìm số 10 đầu tiên xóa 
	//- Xóa nhiều phần tử, xóa hết số 10 trong mảng 
	//- Chèn thêm 1 số 100 vào trong mảng, chèn đầu - cuối - giữa - ...
	//- Hoán đổi giá trị biến của 2 phần tử trong mảng
	return 0;
}