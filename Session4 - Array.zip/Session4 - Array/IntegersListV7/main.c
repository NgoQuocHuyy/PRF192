#include <stdio.h>
#include <stdlib.h>
//Nhập vào từ bàn phím mảng 10 số nguyên bất kì. Hỏi có bao nhiêu số chẵn trong mảng và tính tổng các số lẻ
//I: mảng 
//P: Duyệt mảng, [i] có chẵn không? Không - bỏ qua. Có - count++, có - sum += [i] (nếu chẵn lấy luôn value cộng)
int main(int argc, char *argv[]) {
	//Khai báo mảng 10 số nguyên:
	int n[10];
	int evenCount = 0;
	int sumOdd = 0;
	//Nhập mảng:
	printf("Input 10 numbers:\n");
	for (int i = 0; i < 10; i++) {
		printf("Input number %d: ", (i + 1));
		scanf("%d", &n[i]);
	}
	//In mảng đã nhập:
	printf("You have just input the following numbers\n");
	for (int i = 0; i < 10; i++)
		printf("%d\t", n[i]);
	printf("\n");
	//Xử Lý dữ kiện:
	for (int i = 0; i < 10; i++)
		if(n[i] % 2 == 0)
			evenCount++;
		else 
			sumOdd += n[i]; //Thuật toán nhồi heo đất
	printf("There is/are %d even number(s) in this array.\n", evenCount);
	printf("The sum of odd number(s) in this array is %d.\n", sumOdd);

	return 0;
}
	
	