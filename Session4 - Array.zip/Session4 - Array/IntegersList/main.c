#include <stdio.h>
#include <stdlib.h>

//Nhập một mảng 10 phần tử từ bàn phím, kiểm tra xem số 10 có xuất hiện trong mảng hay không
//I: 10 biến
//P: Thuật toán lôi từng biến ra hỏi value = 10 không, có thì kết luận
//O: In ra có hay không
int main(int argc, char *argv[]) {
	int a[] = {5, 6, -1000, 100, 50, 70, 6, 6, -1, 10};
	//Nên nhớ ta có 10 biến int đó là a[0], a[1],...
	//Duyệt mảng:
	for (int i = 0; i < 10; i++){
		if(a[i] == 10)
			printf("Hey!Found 10 at position %d\n", i);
		else
			printf("Hey!10 not found in the array\n");
	}
	return 0;
}