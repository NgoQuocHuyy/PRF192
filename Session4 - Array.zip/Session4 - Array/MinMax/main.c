#include <stdio.h>
#include <stdlib.h>

//Nhập 1 mảng 10 con số. In ra con số nhỏ nhất, lớn nhất của mảng
//I: Mảng
//P: -5 10 100 -50 1000
//  [0] [1] [2] [3] [4]
//duyệt qua cả mảng, [i] là mấy?
//dùng biến cờ - nguyên tắc giả định cho đến khi thấy sai thì điều chỉnh, không sai thì vẫn đúng
//min = -5
//max = -5
//O: Min, max 2 biến
int main(int argc, char *argv[]) {
	int a[] = {-5, 10, 100, -50, 1000, 1, 2, -50, 1001, 1};
	int min, max;
	min = a[0]; //Gán min cho phần tử đầu tiên của mảng để so sánh
	max = a[0];
	//tìm min, max trong mảng:
	for (int i = 1; i < 10; i++) { //Vì lấy giá trị đầu tức a[0] làm min nên a[i] = 1
		if (a[i] < min)
			min = a[i];
		if (a[i] > max)
			max = a[i];
}
	printf("The min value of this array is:%d\n", min);
	printf("The max value of this array is:%d\n", max);
	return 0;
}