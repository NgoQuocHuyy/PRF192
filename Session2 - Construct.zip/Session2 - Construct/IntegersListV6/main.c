#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Vòng lặp vô tận
// In các số nguyên 1-100
int main(int argc, char *argv[]) {
	printf("The list of integers number of 1-100:\n");
	for (int i = 1; 1 < 100; i++){
		printf("%d ", i);
		if (i == 100)
			break; //Điều kiện thoát đặt trong for
}
		 
	
	
	
	return 0;
}