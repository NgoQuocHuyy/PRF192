#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app in ra các số chẵn từ 1-100
//I: cần số chẵn từ 1-100: 2 4 6 8 10...
//P: Lôi ra được số chẵn, nhỏ nhất là 2 , nhảy cách 2 4 6 8
//O: 
int main(int argc, char *argv[]) {
	printf("The list of Even number to 1 - 100:\n");
	/*
	for (int i = 2; i <= 100; i+=2)
		printf("%d ", i);
	*/
	printf("\n");
	for (int i = 1; i <= 100; i++)
		if ( i % 2 == 0)
			printf("%d ", i);
	return 0;
}