#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
 //Viết app in ra tính cách dựa theo tên gọi
 //dùng kí tự đầu trong tên gọi để luận ra tính cách
 //Áp dụng công thức IPO
 //để bói được tính cách ta cần gì
 //Input: kí tự đầu của tên
 //Output: In ra tính cách tương ứng - printf("câu gì đó"); 
 //Process: Xử lý tùy kí tự tên là gì thì ta sẽ in/ghép với tính cách đã được tổng kết sẵn
 //if(chữ cái là A) thì tính cách là... 
 //if(chữ cái tên đúng là B) thì tính cách là...
 //TIPS: 
      //cứ có bao nhiêu input thì cần bấy nhiêu biến
     //cứ có output thì xác suất cần thêm biến để lưu output, trừ trường hợp ouput in câu gì đó thì k cần
       //Ex: Output của nghiệm phương trình bậc 2: 2 nghiệm x1, x2 cần in ra
    //Phần thuật toán xử lý/process có khả năng cần thêm biến trung gian để lưu các giá trị trong quá trình
    //tính toán. Ex: Bài in tuổi theo năm sinh: age = 2023 - yob;. Age chính là biến trung gian
              //Ex2: Bài toán giải phương trình b2: delta = b^2 - 4ac. Delta là trung gian vì output kp là nó
	//input: chữ cái đầu trong tên gọi
	char fL;
	//process: có tên thì if tương ứng và in ra
	//output: chỉ in kết quả, không cần biến 
	//có biến thì cần value hoặc gán ngay - hard-code hoặc nhập
	printf("Welcome to FPT Diviner.\n");
	printf("You are required the fL in your first name.\n");
	printf("Then I will show you your the fate\n");
	printf("Input your char: ");
	scanf("%c", &fL);
	//có được tên rồi, chỉ là 1 kí tự 
	//fL: 'A'...'Z'
	if(fL == 'A' || fL == 'a')
	  printf("You are a smart person...\n");
	  
	if(fL == 'B' || fL == 'b')
	  printf("You are a beautiful person...\n");
	  
	if(fL == 'C' || fL == 'c')
	  printf("You are a hard worker...\n");
	else
	  printf("Coming soon...\n");
	
	
	
	
	
	
	
	return 0;
}
	