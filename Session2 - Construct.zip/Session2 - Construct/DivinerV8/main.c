#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> 

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	char fL;
	printf("Welcome to FPT Diviner.\n");
	printf("You are required the fL in your first name.\n");
	printf("Then I will show you your the fate.\n");
	printf("Input your char: ");
	scanf("%c", &fL);
	fL = toupper(fL); //Chơi so sánh kí tự hoa, chỉ đổi hệ chữ cái
	//if thay bằng switch 
	switch (fL)
	{
		case 'A':
			printf("You are a smart person...\n");
			break; //Nếu bỏ lệnh break thì sẽ in cả case B!!!
		case 'B':
			printf("You are a beautiful person...\n");
			break;
		case 'C':
			printf("You are a hard worker...\n");
			break;
		default: printf("coming soon..."); 
	}
	
	/*
	if (fL >= 'a' && fL <= 'z')
	  fL -= 32; 
	if(fL == 'A')
	  printf("You are a smart person...\n");
	else if(fL == 'B')
	  printf("You are a beautiful person...\n");
	else if(fL == 'C')
	  printf("You are a hard worker...\n");
	else 
	  printf("Coming soon...");	
	*/
	
	
	return 0;
}