#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app in ra các số tự nhiên từ 1 -> 100
int main(int argc, char *argv[]) {
	printf("The list of 100 first integers (1...100).\n");
	printf("Using standard FOR\n");
	for (int i = 1; i <= 100; i++)
		printf("%d ", i);
		
	
	
	printf("\nUsing For new.\n");
		int count = 1;
		for (;;)
		{
			printf("%d ", count);
			count++;
			if (count == 101)
				break;
		}
	
	
	
	printf("\nUsing Do-while.\n");
	count = 1; //Gọi là side effect. Ta kiểm soát không khéo biến count -> kết quả chạy sai 
	do
	{
		printf("%d ", count);
		count++; //Không được thiếu
	}while (count <= 100); //Không quá 100
	
	
	
	printf("\nUsing while.\n");
	count = 1; //Nhớ side effect từ vòng lặp trước
	while(count < 101)
	{
		printf("%d ", count);
		count++;
	}
	
	
	printf("\nUsing while new.\n");
	count = 50;
	while( 69 == 69)
	{
		printf("%d ", count);
		count++;
		if(count == 101)
			break;
	}
	
	
	
	
	
	
	return 0;
}