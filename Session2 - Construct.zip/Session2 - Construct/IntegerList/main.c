#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//In ra các số từ 1 -100
//I: Không cần vì rõ rồi
//P: Không cần phức tạp, printf()
//O: In ra thôi
int main(int argc, char *argv[]) {
	printf("The list of integers from 1 to 100:\n");
	//for (int i = 1; i <= 100; i++)
	//	printf("%d ", i); //i là index
		                  //Biến siêu cục bộ - local, dùng trong for hết for hết biến 
	for (int i = 100; i < 200; i++)
		printf("%d\t", (i - 99));
		//printf("\n%d\t", i); // Báo lỗi i không tồn tại 
	return 0;
}