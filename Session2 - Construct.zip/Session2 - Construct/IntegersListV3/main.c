#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app in ra các số lẻ từ 1-1000
//O: In ra số lẻ
//P: Lôi ra được số lẻ từ 1-1000
int main(int argc, char *argv[]) {
	printf("The list of odd number to 1-1000:\n");
	for (int i = 1; i <= 1000; i++)
		if (i % 2 == 1) //if (i % 2 != 0)
			printf("%d ", i);
	
	
	
	return 0;
}