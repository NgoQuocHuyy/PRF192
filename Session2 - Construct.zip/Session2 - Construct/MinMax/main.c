#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app nhập 2 số từ bàn phím và in ra số lớn nhất trong 2 số vừa nhập
int main(int argc, char *argv[]) {
	int a, b;
	printf("Please input 2 integers number:\n");	
	scanf("%d%d", &a, &b);
		if ( a > b)
			printf("You input 2 numbers %d and %d.The max number is %d\n", a, b, a);
		else if ( a < b) 
			printf("You input 2 numbers %d and %d. The max number is %d\n", a, b, b);
		else printf("You have 2 equal numbers. They are %d\n", a);
	return 0;
}