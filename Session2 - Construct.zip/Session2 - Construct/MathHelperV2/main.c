#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main(int argc, char *argv[]) {
	int choice;
	float radius, sideLength, area1, area3;
	int width, length, area2;
	
	do
	{
		printf("Welcome to FPT Math Helper program.\n");
	    printf("Please choose the following function to play with.\n");
	    printf("1. Compute the disk area\n");
	    printf("2. Compute the rectangle area\n");
	    printf("3. Compute the triangle area\n");
	    printf("4. Quit\n");
	    printf("Choose 1 - 4:");
	    scanf("%d", &choice);
	    
	    switch (choice)
	 {
		case 1:
			printf("You choose 1 to compute the disk area.\n");
			printf("Please input a disk radius:");  
			scanf("%f", &radius);
			area1 = 3.14 * radius * radius;
			printf("The disk with r = %.2f has the area of %.2f\n", radius, area1);
			break;
		case 2:
			printf("You choose 2 to compute the rectangle area.\n");
			printf("Please input a width: \n");
			printf("Please input a length: \n");
			scanf("%d%d", &width, &length);
			area2 = width * length;
			printf("The rectangle with width is %d and length is %d has the area of %d\n", width, length, area2);
			break;
		case 3:
			printf("You choose 3 to compute the triangle area.\n");
			printf("Please input a sideLength: \n");
			scanf("%f", &sideLength);
			area3 = sideLength * sideLength;
			printf("The triangle with sideLength is %.2f has the area of %.2f\n", sideLength, area3);
			break;
		case 4:
			printf("See you next time!");
			break;
		default: 
		    printf("Please choose 1 - 4!\n");
	 }                   
	   
	} while (choice != 4); //Chừng nào còn chưa chọn 4 thì chơi tiếp 
	                       //đúng là choice chưa bằng 4 thì chơi tiếp trong do 
	return 0;
}