#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app hỗ trợ làm các phép toán cơ bản. App cung cấp tính năng menu 1,2,3,...,10 
//ai muốn chơi tính năng nào thì chọn con số đó
//Ex: chọn 1 để tính diện tích hình tròn - IPO (r -> area)
//2. Tính diện tích hcn - IPO (w,l -> area)
//3....
//10.Quit
//IPO của cả bài...
//Cần gì ở bài menu này một cách tổng quát ???
 //I: Chọn mấy? 
 //   biến choice/option/menuItem;
 //P: xử lí, tùy choice là gì thì ta hành xử tương ứng menu. Có nhiều choice -> switch case/if else 
 //O: Tùy chọn gì thì có output tương ứng 
int main(int argc, char *argv[]) {
	int choice;
	float radius, area;
	int width, length;
	printf("Welcome to FPT Math Helper program.\n");
	printf("Please choose the following function to play with.\n");
	printf("1. Compute the disk area\n");
	printf("2. Compute the rectangle area\n");
	printf("3. Compute the triangle area\n");
	printf("4. Quit\n");
	printf("Choose 1 - 4:");
	scanf("%d", &choice);
	switch (choice)
	{
		case 1:
			//CPU vào đây xử lý vụ hình tròn.IPO là bk, dt, chu vi.
			printf("You choose 1 to compute the disk area.\n");
			printf("Please input a disk radius:"); //gõ bán kính âm 
			scanf("%f", &radius);
			area = 3.14 * radius * radius;
			printf("The disk with r = %.2f has the area of %.2f\n", radius, area);
			break;
		case 2:
			printf("You choose 2 to compute the rectangle area.\n");
			printf("Please input a width: \n");
			printf("Please input a length: \n");
			scanf("%d%d",&width, &length);
			
			break;
		case 3:
			break;
		case 4:
			printf("See you next time!");
			break;
		default: 
		    printf("Please choose 1 - 4!");
	}
	return 0;
}