#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Vòng lặp vô tận
// In các số nguyên 1-100
int main(int argc, char *argv[]) {
	printf("The list of integers number of 1-100:\n");
	int count = 1; //Trong for dùng index, ngoài for dùng count làm biến đếm 
	for (;;) //Không khởi đầu, không kết thúc , không đếm gì cả
	{
		printf("%d ", count);
		count++;
		if (count == 101)
			break; //Điều kiện thoát đặt trong for
	}
		 
	
	
	
	return 0;
}