#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app in ra các số tự nhiên từ 1 - n (n > 1)
//I: cần n -> 1 biến n -> có value -> cần scanf
//P: for và if nếu cần
int main(int argc, char *argv[]) {
	int n;
	printf("The list of integers number from 1 to n (>1)\n");
	printf("Input n>1: ");
	scanf("%d", &n);
	
	if (n < 1)
		printf("Do you know how to input a number > 1?\n");
	else 
	{
		printf("The list of number from 1 to %d:\n", n);
		for (int i = 1; i <= n; i++)
			printf("%d ", i);	
	}
	
	
	
	
	return 0;
}