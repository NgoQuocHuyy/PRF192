#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app tính tổng của dãy số từ 1 -> n ( n> 1 )
// I: biến n
// P, O đã biết
int main(int argc, char *argv[]) {
	int n, acc = 0;
	printf("This program will show the sum of n first integers (1..n)\n");
	printf("Please input n > 1: ");
	scanf("%d", &n);
		//Nếu bảo nhập n > 1 mà gõ -5, 0,...
	if (n <= 1)
		printf("Do you know how to input an integer > 1.\n"); 
	else
	{	
		for (int i = 1; i <= n; i++)
		acc += i;
		printf("The sum is %d\n", acc);
	}
	
	
	
	
	
	return 0;
}