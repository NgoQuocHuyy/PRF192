#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Viết app tính tổng của dãy số 1 + 2 + 3 +...+ 100.
// I: Đã rõ đầu vào nên k cần, bao nhiêu đầu vào bấy nhiêu biến  
// P: xử lý đầu vào, có thể dùng biến trung gian //
//O: kết quả cuối, đưa vào, nhận về gì/đầu ra
// tổng: P = 1+2+3+4+
//đầu ra: biến chứa value như là cái kết xuất hoặc là câu thông báo gì đó về giá trị -> biến -> value 
int main(int argc, char *argv[]) {
	int acc = 0;
	printf("This program will show the sum of 100 first integers (1...100).\n");
	for (int i = 1; i <= 100; i++)
		acc += i;
		printf("The sum is %d", acc);
	
	return 0;
}