#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Vòng lặp vô tận
// In các số nguyên 1-100
int main(int argc, char *argv[]) {
	
	//for (int i = 1; i <= 100; i++)
	//printf("%d ", i);
	printf("The list of integers number of 1-100:\n");
	for (int i = 1; 1 < 100; i++)
		printf("%d ", i); //Đúng mãi bất chấp i
		                  //Điều kiện thoát biến đếm, tức là vòng lặp vô tận
		                  
		                  
		 
	
	
	
	return 0;
}