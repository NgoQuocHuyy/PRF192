#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
 // Viết app nhập vào năm sinh và kiểm tra xem đủ tuổi vào quán bar hay k >= 18
 // Để giải quyết bài toán ta cần INPUT tuổi tức là năm sinh, OUTPUT cho vào bar hoặc không
   //Cứ có input là cần có biến (để lưu value cho input)
 //Process: có năm sinh ta ra tuổi -> quyết định vào bar hay không và thông báo 

int main(int argc, char *argv[]) {
	int yob, age;
	printf("Welcome to FPT bar\n");
	printf("Please show your yob:");
	scanf("%d", &yob);
	
	age = 2023 - yob;
	if(age >= 18) 
	  printf("Let's chill\n");
	else  // Bao hàm cả câu lệnh if(age < 18) 
	  printf("Please out of the door\n");
	return 0;
}
	return 0;
}