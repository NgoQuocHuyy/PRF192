#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Hyax in ra 10 câu chào chúc mừng năm mới song ngữ Anh - Việt
//IPO: K cần I rõ ràng vì đã rõ, chỉ cần in ra O. K cần biến gì cả
int main(int argc, char *argv[]) {
	//for (int i = 1; i <= 10; i++)
		//printf("Chuc mung nam moi!!! - Happy New Year 2023!!!\n");
	for (int i = 1; i <= 100; i++)
	   printf("%d\n", i);
	//in các số từ 1 - 100
	return 0;
}