#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
// Tính tổng các số từ 1 -> 100 và in ra kết quả (5050)
int main(int argc, char *argv[]) {
	int sum = 0; //Heo ban đầu rỗng
	printf("This program will compute the sum of 100 first integers.\n");
	for (int i = 1; i < 101; i++)
		sum += i;
		
	printf("Sum (FOR): %d\n", sum);
	int count = 1;
	sum = 0; //Side effect
	do
	{
		sum += count;
		count++;
	}while (count < 101);
		printf("Sum (WHILE): %d", sum);
	return 0;
}