#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//Viết app tìm giá trị lớn nhất trong 3 số
int main(int argc, char *argv[]) {
	int a, b, c, max;
	printf("Find max between 3 numbers:\n");
	printf("Input 3 integers: ");
	scanf("%d%d%d", &a, &b, &c);
	 max = a; //có thể đúng hoặc sai 
	 	if (b > max)
	 		max = b;
	 	if (c > max)
			max = c;
		printf("Max number between %d %d %d is %d\n", a, b, c, max);
		if ( a == b && b == c)
				printf("All 3 numbers are equal.\n");
	return 0;
}